package com.example.bgrecorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.camera2.CaptureRequest
import android.os.PowerManager
import android.provider.MediaStore
import android.util.Range
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordService : LifecycleService() {

    private var cameraProvider: ProcessCameraProvider? = null
    private var recording: Recording? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> stopRecording()
            else -> {
                val quality = intent?.getStringExtra(EXTRA_QUALITY) ?: "FHD"
                val fps = intent?.getIntExtra(EXTRA_FPS, 30) ?: 30
                startRecording(quality, fps)
            }
        }
        return START_NOT_STICKY
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun startRecording(qualityName: String, fps: Int) {
        if (recording != null) return

        createChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(qualityName, fps),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BgRecorder::Rec")
            .apply { acquire(4 * 60 * 60 * 1000L) }

        val quality = if (qualityName == "UHD") Quality.UHD else Quality.FHD

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            cameraProvider = provider

            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(
                        quality,
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                    )
                )
                .build()

            // Camera2Interop se target FPS set karte hain. Device jis max ko
            // support kare usi tak milega; agar ye combination (resolution+fps)
            // supported nahi hai to system nearest valid range chun lega.
            val videoCaptureBuilder = VideoCapture.Builder(recorder)
            Camera2Interop.Extender(videoCaptureBuilder)
                .setCaptureRequestOption(
                    CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE,
                    Range(fps, fps)
                )
            val videoCapture = videoCaptureBuilder.build()

            provider.unbindAll()
            provider.bindToLifecycle(
                this, CameraSelector.DEFAULT_BACK_CAMERA, videoCapture
            )

            val name = "VID_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/BgRecorder")
            }
            val output = MediaStoreOutputOptions.Builder(
                contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            ).setContentValues(values).build()

            recording = videoCapture.output
                .prepareRecording(this, output)
                .withAudioEnabled()
                .start(ContextCompat.getMainExecutor(this)) { event ->
                    if (event is VideoRecordEvent.Finalize) cleanup()
                }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopRecording() {
        val r = recording
        if (r != null) r.stop() else cleanup()
    }

    private fun cleanup() {
        recording = null
        cameraProvider?.unbindAll()
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createChannel() {
        val ch = NotificationChannel(
            CHANNEL_ID, "Recording", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    // Is notification ko hide ya suppress nahi kiya ja sakta (aur nahi kiya jayega):
    // Android camera/mic foreground service ke liye ye system requirement hai,
    // taaki user ko hamesha pata rahe ke recording chal rahi hai.
    private fun buildNotification(qualityName: String, fps: Int): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, RecordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setContentTitle("Recording... ($qualityName @ ${fps}fps)")
            .setContentText("Back camera video recording chal rahi hai")
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.example.bgrecorder.STOP"
        const val EXTRA_QUALITY = "extra_quality"
        const val EXTRA_FPS = "extra_fps"
        private const val CHANNEL_ID = "rec_channel"
        private const val NOTIF_ID = 1
    }
}
