package com.example.bgrecorder

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var qualitySpinner: Spinner
    private lateinit var fpsSpinner: Spinner

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true &&
            result[Manifest.permission.RECORD_AUDIO] == true
        ) {
            startRec()
        } else {
            Toast.makeText(this, "Camera aur Mic permission chahiye", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        qualitySpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("1080p (FHD)", "4K (UHD)")
            )
        }
        fpsSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("30 fps", "60 fps")
            )
        }

        val startBtn = Button(this).apply {
            text = "Start Recording"
            setOnClickListener { askPermsAndStart() }
        }
        val stopBtn = Button(this).apply {
            text = "Stop Recording"
            setOnClickListener {
                startService(
                    Intent(this@MainActivity, RecordService::class.java)
                        .setAction(RecordService.ACTION_STOP)
                )
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            addView(TextView(this@MainActivity).apply { text = "Quality:" })
            addView(qualitySpinner)
            addView(TextView(this@MainActivity).apply { text = "Frame rate:" })
            addView(fpsSpinner)
            addView(startBtn)
            addView(stopBtn)
        })
    }

    private fun askPermsAndStart() {
        val perms = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }

    private fun startRec() {
        val quality = if (qualitySpinner.selectedItemPosition == 1) "UHD" else "FHD"
        val fps = if (fpsSpinner.selectedItemPosition == 1) 60 else 30

        val intent = Intent(this, RecordService::class.java)
            .putExtra(RecordService.EXTRA_QUALITY, quality)
            .putExtra(RecordService.EXTRA_FPS, fps)
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(
            this, "Recording started ($quality @ ${fps}fps). Ab screen off kar sakte ho",
            Toast.LENGTH_SHORT
        ).show()
    }
}
