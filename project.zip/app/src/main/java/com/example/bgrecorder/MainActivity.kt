package com.example.bgrecorder

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true &&
            result[Manifest.permission.RECORD_AUDIO] == true
        ) {
            startRec()
        } else {
            Toast.makeText(this, "Camera aur Mic permission chahiye", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val startBtn = Button(this).apply {
            text = "Start Recording"
            setOnClickListener { askPermsAndStart() }
        }
        val stopBtn = Button(this).apply {
            text = "Stop Recording"
            setOnClickListener {
                startService(
                    Intent(this@MainActivity, RecordService::class.java)
                        .setAction(RecordService.ACTION_STOP)
                )
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            addView(startBtn)
            addView(stopBtn)
        })
    }

    private fun askPermsAndStart() {
        val perms = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(perms.toTypedArray())
    }

    // Activity foreground mein hai tabhi service start hoti hai (Android 14+ requirement)
    private fun startRec() {
        ContextCompat.startForegroundService(this, Intent(this, RecordService::class.java))
        Toast.makeText(this, "Recording started. Ab screen off kar sakte ho", Toast.LENGTH_SHORT).show()
    }
}
